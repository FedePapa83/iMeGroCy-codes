%% Default commands
clear all
close all
clc
dbstop if error
format compact

str1  = clock;
str2 = ([num2str(str1(1)),'-',num2str(str1(2)),'-',num2str(str1(3)),'-',num2str(str1(4)),'-',num2str(str1(5)),'-',num2str(str1(6))]);
mkdir(str2)
tic

%% Variables for the Probability Matrices
n  = [4 4 8];
ns = n(1);
nw = n(2);
no = n(3);
nd  = ns + 2;

%% Probability Matrix Definition�
[Pm.D_d, Pm.D_k, Pm.Fd, Pm.Ud, Pm.T_t, Pm.T_b, Pm.T_k, Pm.T_w, Pm.Ft, Pm.Ut, Pm.Hb, nrr] = Prob_matrices(ns,nw,no,'wt');

%% Initial Parameters Definition;
[G_0, CYF_0, G1S_0, CLNB_0, S1_0, Eta_0, Sigma_0, MA_0] = parameters(nw);
% PDET is a vector of: 
% [(1) Parent (0)/Daughter (1), (2) Genealogical Age, (3) Index of time birth, (4) TB - TG1* length, (5) TG1* length, 
%  (6) Simulation phase, (7) Index of transition T1->T2, (8) Index of transition T2->TB, (9) Index of transition TB->TG1*, (10) Index of Tcd, (11) Last instant of integration];
% Simulation phase: 0 = T1, 1 = T2, 2 = TB (before G1*), 3 = TG1*, 4 = divided cell
PDET_0 = [1 1 0 0 0 0 0 0 0 0 0]';
% Ng structure contains the number of genes of types A, B and C
Ng.NA  = 136;
Ng.NB  = 63;
Ng.NC  = 36;

P_0 = 3.03E10;        %2%

VP  = 0.03;
VIC = 0.03;
VTB = 0.03;

[Xf(:,1), G(:,1), CYF(:,1), G1S(:,1), CLNB(:,1), S1(:,1), Eta(:,1), MA(:,1), PDET(:,1)] = Generation_CI(P_0, G_0, CYF_0, G1S_0, CLNB_0, S1_0, Eta_0, Sigma_0, MA_0, PDET_0, VP, VIC, VTB, nw, nd ,nrr);

dt              = 1e-4;
T1_HighDynamics = 1;
passoT1_Large   = 1e-3;
passoT2         = 1e-3;
passoTB         = 0.1;

Timer = [0 0 PDET(4) PDET(5) 0]'; % [(1) T1, (2) T2, (3) TB-TG1*, (4) TG1*, (5) Tcycle];
Protein = [P_0 0 0 0 0]'; % [(1) P0 , (2) Ps, (3) Pcd, (4) P0 Parent, (5) P0 Daughter]; 
Ncfinali = 5; % Number of cells of the population

A = [0, size(Xf,2), sum(PDET(1,:)==0), sum(PDET(1,:)==1), sum(PDET(6,:)==0), sum(PDET(6,:)==1), sum(PDET(6,:)==2), sum(PDET(6,:)==3), sum(PDET(6,:)==4), sum(Xf(1,:)), 0, Xf(1,1)];
%A=[(1) current instant, (2) Total number of cells, (3) Total number of Parent cells, (4) Total number of Daughter cells, (5) Number of Cells in T1, (6) Number of Cells in T2, 
%(7) Number of Cells in TB (before G1*), (8) Number of Cells in TG1*, (9) Number of Cells at division, (10) Protein Content of the population, (11) P0 Parent, (12) P0 Daughter]


%Growth of the population up to Ncfinali

i = 0; %Index of time
ncs=0;

while size(Xf,2) < Ncfinali 

    %Selection of cells to be integrated
    if (mod(i, 5/dt) == 0)  
        ncdi = 1:1:size(Xf,2);    
    else   
        [a, ncdi]= find(( PDET(6,:) == 0 ) | ... %& ((i - PDET(3,:))*dt <= T1_HighDynamics) ) | ...
                        ( PDET(6,:) == 1 & ((i - PDET(11,:))*dt == passoT2) ) | ...
                        ( PDET(6,:) == 2 & ((i - PDET(11,:))*dt == passoTB) ) | ...
                        ( PDET(6,:) == 3 & ( ((i - PDET(11,:))*dt == passoTB) | (i > (PDET(4,:) + PDET(5,:))/dt + PDET(8,:)) ) ) | ...
                        ( PDET(6,:) == 4 ) );
    end
    
    for j = ncdi %1:size(Xf,2) %index of the current cell
        
        if PDET(6,j) == 0 && ((i - PDET(3,j))*dt <= T1_HighDynamics)  
            [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
            Xf(:,j) = Xf(:,j) + dX*dt;
        elseif PDET(6,j) == 0 && ((i - PDET(3,j))*dt > T1_HighDynamics) && ((i - PDET(11,j))*dt == passoT1_Large)
            dT = (i - PDET(11,j))*dt;   
            [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
            Xf(:,j) = Xf(:,j) + dX*dT;  
        elseif PDET(6,j) == 1
            dT = (i - PDET(11,j))*dt;   
            [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
            Xf(:,j) = Xf(:,j) + dX*dT; 
        elseif (PDET(6,j) == 2 || PDET(6,j) == 3)    
            dT = (i - PDET(11,j))*dt;   
            [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_TB(Xf(:,j), G(:,j), PDET(:,j), dt, i, Protein(:,j), Timer(:,j));
            Xf(:,j) = Xf(:,j) + dX*dT;
        end
        
        %Duplication
        if PDET(6,j) == 4
            
            num_cell = size(Xf,2);
            
            if PDET(1,j) == 1; %If it is a Daughter
                g_m = 0;
            else
                g_m = PDET(2,j); %If it is a Parent
            end
            
            t_n      = PDET(10,j);
            
            Pip = max(0.0001*Protein(2,j), Protein(2,j)*(1+VIC*randn)); %Parent Initial Protein Content
            Pid = Protein(3,j) - Pip;                                   %Daughter Initial Protein Content
            Protein(4,j)=Pip;
            Protein(5,j)=Pid;
            
            % Parent  [0 gm+1 tn 0 0 0 0 0 i]'
            [Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j)] = Generation_CI(Pip, G_0, CYF_0, G1S_0, CLNB_0, S1_0, Eta_0, Sigma_0, MA_0, [0 (g_m+1) t_n 0 0 0 0 0 0 0 i]', VP, VIC, VTB, nw, nd , nrr);
            
            % Daughter [1 gm+1 tn 0 0 0 0 0 i]'
            [Xf(:,num_cell+1), G(:,num_cell+1), CYF(:,num_cell+1), G1S(:,num_cell+1), CLNB(:,num_cell+1), S1(:,num_cell+1), Eta(:,num_cell+1), MA(:,num_cell+1), PDET(:,num_cell+1)] = Generation_CI(Pid, G_0, CYF_0, G1S_0, CLNB_0, S1_0, Eta_0, Sigma_0, MA_0, [1 (g_m+1) t_n 0 0 0 0 0 0 0 i]', VP, VIC, VTB, nw, nd ,nrr);
            
            Timer(:,j) = [0 0 PDET(4,j) PDET(5,j) 0]';
            Timer(:,num_cell+1) = [0 0 PDET(4,num_cell+1) PDET(5,num_cell+1) 0]';
            Protein(:,j) = [Pip 0 0 0 0]';
            Protein(:,num_cell+1) = [Pid 0 0 0 0]';
  
        end
        
    end
    
    if mod(i*dt,5)==0 
        A = [i*dt, size(Xf,2), sum(PDET(1,:)==0), sum(PDET(1,:)==1), sum(PDET(6,:)==0), sum(PDET(6,:)==1), sum(PDET(6,:)==2), sum(PDET(6,:)==3), sum(PDET(6,:)==4), sum(Xf(1,:)), 0, 0];
        %A=[(1) current instant, (2) Total number of cells, (3) Total number of Parent cells, (4) Total number of Daughter cells, (5) Number of Cells in T1, (6) Number of Cells in T2, 
        %(7) Number of Cells in TB (before G1*), (8) Number of Cells in TG1*, (9) Number of Cells at division, (10) Protein Content of the population, (11) P0 Parent, (12) P0 Daughter]
        disp(num2str([A(end,1:end-2),ncs]));
    end
    
    i = i+1;
    
    %Controlling if the variables are physically meaningful    
    [a,cell_errate]=find(isnan(Xf));

    if isempty(cell_errate)==0
       
       cell_errate=unique(cell_errate)';

       disp('Cellule eliminate:');
       disp(num2str(PDET(:,cell_errate)));
       
       Xf(:,cell_errate)=[];
       G(:,cell_errate)=[];
       CYF(:,cell_errate)=[];
       G1S(:,cell_errate)=[];
       CLNB(:,cell_errate)=[];
       S1(:,cell_errate)=[];       
       Eta(:,cell_errate)=[];
       MA(:,cell_errate)=[];
       PDET(:,cell_errate)=[];
       Protein(:,cell_errate)=[];
       Timer(:,cell_errate)=[];
       
       ncs = ncs + length(cell_errate);
       
    end
    
end


%Last integration in tf

for j = 1:size(Xf,2) 
        
    if PDET(6,j) == 0 && ((i - PDET(3,j))*dt <= T1_HighDynamics)  
        [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
        Xf(:,j) = Xf(:,j) + dX*dt;
    elseif PDET(6,j) == 0 && ((i - PDET(3,j))*dt > T1_HighDynamics) && ((i - PDET(11,j))*dt == passoT1_Large)
        dT = (i - PDET(11,j))*dt;   
        [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
        Xf(:,j) = Xf(:,j) + dX*dT;  
    elseif PDET(6,j) == 1 && ( ((i - PDET(11,j))*dt == passoT2) || (mod(i, 5/dt) == 0) )
        dT = (i - PDET(11,j))*dt;   
        [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
        Xf(:,j) = Xf(:,j) + dX*dT; 
    elseif (PDET(6,j) == 2 || PDET(6,j) == 3) && ( ((i - PDET(11,j))*dt == passoTB) || (mod(i, 5/dt) == 0) || (PDET(6,j) == 3 && i > (PDET(4,j) + PDET(5,j))/dt + PDET(8,j)) )           
        dT = (i - PDET(11,j))*dt;   
        [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_TB(Xf(:,j), G(:,j), PDET(:,j), dt, i, Protein(:,j), Timer(:,j));
        Xf(:,j) = Xf(:,j) + dX*dT;
    end
        
end

ProtDistr=Xf(1,:);
RibDistr=Xf(2,:);

A = [i*dt, size(Xf,2), sum(PDET(1,:)==0), sum(PDET(1,:)==1), sum(PDET(6,:)==0), sum(PDET(6,:)==1), sum(PDET(6,:)==2), sum(PDET(6,:)==3), sum(PDET(6,:)==4), sum(Xf(1,:)), 0, 0];
%A=[(1) current instant, (2) Total number of cells, (3) Total number of Parent cells, (4) Total number of Daughter cells, (5) Number of Cells in T1, (6) Number of Cells in T2, 
%(7) Number of Cells in TB (before G1*), (8) Number of Cells in TG1*, (9) Number of Cells at division, (10) Protein Content of the population, (11) P0 Parent, (12) P0 Daughter]
disp(num2str([A(end,1:end-2),ncs]));
a=toc;
disp(num2str(a))

%Saving Workspace data  
save(['./',num2str(str2),'/Dati_',num2str(Ncfinali),'_cellule.mat'])


%Integration up to death of the whole population for the computation of the
%final statistics

tic

i = i+1;

while sum(PDET(6,:)==4) ~= size(Xf,2) 

    [a, ncnd]=find(PDET(6,:)~= 4); %Current number of undivided cells
    
    for j = ncnd 
        
        if PDET(6,j) == 0 && ((i - PDET(3,j))*dt <= T1_HighDynamics)
            [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
            Xf(:,j) = Xf(:,j) + dX*dt;
        elseif PDET(6,j) == 0 && ((i - PDET(3,j))*dt > T1_HighDynamics) && ((i - PDET(11,j))*dt == passoT1_Large)       
            dT = (i - PDET(11,j))*dt;   
            [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
            Xf(:,j) = Xf(:,j) + dX*dT;  
        elseif PDET(6,j) == 1 && ( ((i - PDET(11,j))*dt == passoT2) || (mod(i, 5/dt) == 0) )
            dT = (i - PDET(11,j))*dt;   
            [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_T1(Xf(:,j), G(:,j), CYF(:,j), G1S(:,j), CLNB(:,j), S1(:,j), Eta(:,j), MA(:,j), PDET(:,j), Pm, Ng, nd, nw, nrr, dt, i, Protein(:,j), Timer(:,j));
            Xf(:,j) = Xf(:,j) + dX*dT; 
        elseif (PDET(6,j) == 2 || PDET(6,j) == 3) && ( ((i - PDET(11,j))*dt == passoTB) || (mod(i, 5/dt) == 0) || (PDET(6,j) == 3 && i > (PDET(4,j) + PDET(5,j))/dt + PDET(8,j)) )             
            dT = (i - PDET(11,j))*dt;   
            [dX, PDET(:,j), Protein(:,j), Timer(:,j)] = Integration_TB(Xf(:,j), G(:,j), PDET(:,j), dt, i, Protein(:,j), Timer(:,j));
            Xf(:,j) = Xf(:,j) + dX*dT;
        end
        
    end
    
    if mod(i*dt,5)==0
        A = [i*dt, size(Xf,2), sum(PDET(1,:)==0), sum(PDET(1,:)==1), sum(PDET(6,:)==0), sum(PDET(6,:)==1), sum(PDET(6,:)==2), sum(PDET(6,:)==3), sum(PDET(6,:)==4), sum(Xf(1,:)), 0, 0];
        %A=[(1) current instant, (2) Total number of cells, (3) Total number of Parent cells, (4) Total number of Daughter cells, (5) Number of Cells in T1, (6) Number of Cells in T2, 
        %(7) Number of Cells in TB (before G1*), (8) Number of Cells in TG1*, (9) Number of Cells at division, (10) Protein Content of the population, (11) P0 Parent, (12) P0 Daughter]
        disp(num2str(A(end,1:end-2)));
        disp(['Cellule morte:', num2str(sum(PDET(6,:)==4))]);
    end
    
    i = i+1;
    
end

A = [i*dt, size(Xf,2), sum(PDET(1,:)==0), sum(PDET(1,:)==1), sum(PDET(6,:)==0), sum(PDET(6,:)==1), sum(PDET(6,:)==2), sum(PDET(6,:)==3), sum(PDET(6,:)==4), sum(Xf(1,:)), 0, 0];
%A=[(1) current instant, (2) Total number of cells, (3) Total number of Parent cells, (4) Total number of Daughter cells, (5) Number of Cells in T1, (6) Number of Cells in T2, 
%(7) Number of Cells in TB (before G1*), (8) Number of Cells in TG1*, (9) Number of Cells at division, (10) Protein Content of the population, (11) P0 Parent, (12) P0 Daughter]
disp(num2str(A(end,1:end-2)));
disp(['Cellule morte:', num2str(sum(PDET(6,:)==4))]);

a=toc;
disp(num2str(a))


%Computation of the final statistics

%Statistics of the whole population

T1_pop=mean(Timer(1,:));
T2_pop=mean(Timer(2,:));
TG1_pop=mean(Timer(1,:)+Timer(2,:));
TB_pop=mean(Timer(3,:)+Timer(4,:));
TG1star_pop=mean(Timer(4,:));
Tcd_pop=mean(Timer(5,:));

P0_pop=mean(Protein(1,:));
Ps_pop=mean(Protein(2,:));
Pcd_pop=mean(Protein(3,:));


%Statistics of parent and daughter subpopulations

[a,parent]=find(PDET(1,:)==0);
[a,daughter]=find(PDET(1,:)==1);

T1_parent=mean(Timer(1,parent));
T1_daughter=mean(Timer(1,daughter));

T2_parent=mean(Timer(2,parent));
T2_daughter=mean(Timer(2,daughter));

TG1_parent=mean(Timer(1,parent)+Timer(2,parent));
TG1_daughter=mean(Timer(1,daughter)+Timer(2,daughter));

TB_parent=mean(Timer(3,parent)+Timer(4,parent));
TB_daughter=mean(Timer(3,daughter)+Timer(4,daughter));

TG1star_parent=mean(Timer(4,parent));
TG1star_daughter=mean(Timer(4,daughter));

Tcd_parent=mean(Timer(5,parent));
Tcd_daughter=mean(Timer(5,daughter));

P0_parent=mean(Protein(1,parent));
P0_daughter=mean(Protein(1,daughter));

Ps_parent=mean(Protein(2,parent));
Ps_daughter=mean(Protein(2,daughter));

Pcd_parent=mean(Protein(3,parent));
Pcd_daughter=mean(Protein(3,daughter));

Period=[T1_pop, T1_parent, T1_daughter; T2_pop, T2_parent, T2_daughter; TG1_pop, TG1_parent, TG1_daughter; ...
    TB_pop, TB_parent, TB_daughter; TG1star_pop, TG1star_parent, TG1star_daughter; Tcd_pop, Tcd_parent, Tcd_daughter];

ProteinContent=[P0_pop, P0_parent, P0_daughter; Ps_pop, Ps_parent, Ps_daughter; Pcd_pop, Pcd_parent, Pcd_daughter];


%Saving Workspace data
save(['./',num2str(str2),'/Dati_',num2str(Ncfinali),'_celluleFinali.mat'])
