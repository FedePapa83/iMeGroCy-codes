close all;
clear;
clc;

global ferm c_glcex c_EtOHex;
global nu_rib;
global c_AXP;

global gamma_hxt; 
global NprotRib;

global kcat_hxt kcat_gly kcat_rib kcat_resp kcat_ferm;
global kcat_EtOH kcat_resp2 kcat_gly2;

global KM_hxt KM_gly KM_rib KM_resp KM_ferm KM_gly_ADP KM_resp_ADP KM_rib_ATP;
global KM_EtOH KM_resp2 KM_resp2_ADP KM_gly2 KM_gly2_ATP;

global KI_pyr KI_glcin KI2_glcin;

global s_1 s_2 s_3 s_4 s_5 s_6 s_7 s_8 s_9 s_10 s_11 s_12 s_13 s_14 s_15 s_16;


%% Model parameters (see Supplementary Table S2)

kcat_hxt  = 37492;
kcat_gly  = 4166;
kcat_rib  = 670;
kcat_resp = 99;
kcat_ferm = 6427;

kcat_EtOH  = 964080; 
kcat_resp2 = 221; 
kcat_gly2  = 12497; 

KM_hxt      = 20;
KM_gly      = 0.2;
KM_rib      = 1;
KM_resp     = 0.5;
KM_ferm     = 5;
KM_gly_ADP  = 0.5;
KM_resp_ADP = 0.5;
KM_rib_ATP  = 0.5;

KM_EtOH      = 0.05; 
KM_resp2     = 0.05;
KM_resp2_ADP = KM_resp_ADP; 
KM_gly2      = KM_gly;
KM_gly2_ATP  = KM_gly_ADP; 

KI_pyr    = 1;
KI_glcin  = 1;
KI2_glcin = 1;

%%
% Stoichiometric coefficients for glc_in (see Eq.(12), STAR Methods)
s_1 = 1.0;  
s_2 = -1.0;
s_3 = 1.0;

% Stoichiometric coefficients for pyr (see Eq.(12), STAR Methods)
s_4 = 2.0;
s_5 = -1.0;
s_6 = -1.0;
s_7 = -600.0;

% Stoichiometric coefficients for ATP (see Eq.(12), STAR Methods)
s_8 = 2.0;
s_9 = -2000.0;
s_10 = 10.0;
s_11 = 5.0;
s_12 = -8.0;

% Stoichiometric coefficients for EtOH_in (see Eq.(12), STAR Methods)
s_13 = 1.0;
s_14 = -1.0;
s_15 = -2.0;
s_16 = -1.0;

%% Fixed variables

nu_rib = 1;                     
c_AXP  = 1;

%% Scaling Factors (see Supplementary Table S2)

NprotRib    = 79;      % Mean value of proteins per ribosomes 
NaaProt     = 441.5;   % Mean value of aa per protein
NaaProtRib  = 157.5;   % Mean value of aa per ribosomal protein
Scaling_rho = NprotRib*NaaProtRib/NaaProt;  % See Eq. 17 in STAR Methods

%% Optimization options

options = optimoptions('fmincon', ... 
    'Algorithm', 'sqp', 'MaxFunEvals', 100000, 'MaxIter', 1000); 
    
%% Output files 

% MeGro Output in glucose environment (c_EtOHex = 0)

flamb1     = fopen('Results/Lambda_Exper1.txt','w');
frho1      = fopen('Results/Rho_Exper1.txt','w');  %#rib/#aa
fglcex1    = fopen('Results/ConcGlcEst_Exper1.txt','w');
fpercferm1 = fopen('Results/PercentFermFlux_Exper1.txt','w');
fEtOHex1   = fopen('Results/ConcEtOHEst_Exper1.txt','w');


% MeGro Output in ethanol environment (c_glcex=0)

flamb2     = fopen('Results/Lambda_Exper2.txt','w');
frho2      = fopen('Results/Rho_Exper2.txt','w');  %#rib/#aa
fglcex2    = fopen('Results/ConcGlcEst_Exper2.txt','w');
fpercferm2 = fopen('Results/PercentFermFlux_Exper2.txt','w');
fEtOHex2   = fopen('Results/ConcEtOHEst_Exper2.txt','w');

fgammahxt2  = fopen('Results/Gamma_hxt_Exper2.txt','w');

%% Pure glucose environment (c_EtOHex = 0) 

% External ethanol concentration
c_EtOHex = 0.0;

% Data for the external glucose concentration and the fermentative ratio
% WT - CEN.PK
Data_c_glcex   = [0.05 0.1 0.2 0.5 2 5]/180.1559*10000;                                                 % (1)Glucose 0.05%; (2)Glucose 0.1%; (3)Glucose 0.2%; (4)Glucose 0.5%; (5)Glucose 2%; (6)Glucose 5%; (mM)
Data_F         = [8.035546e-01; 8.826359e-01; 9.283157e-01; 9.580659e-01; 9.736677e-01; 9.768492e-01];	% (1)Glucose 0.05%; (2)Glucose 0.1%; (3)Glucose 0.2%; (4)Glucose 0.5%; (5)Glucose 2%; (6)Glucose 5%;

% Initializing optimization variables
c_glcin_0    = 1e-02;
c_pyr_0      = 1;
c_ATP_0      = 1e-02;
c_EtOHin_0   = 1e-03;

for i = 1:1:length(Data_F)
    
    % Current fermentative ratio
    ferm     = Data_F(i);
    % Current external glucose concentration
    c_glcex  = Data_c_glcex(i);

    % Optimization problem

    x0  = [c_glcin_0 c_pyr_0 c_ATP_0 c_EtOHin_0];
    A   = [];
    b   = [];
    Aeq = [];
    beq = [];
    lb  = [0 0 0 0]; 
    ub  = [10 10 1 10]; 

    [x_ott, J_ott, EXITFLAG] = fmincon('MinusLambda', x0,A,b,Aeq,beq,lb,ub,'EtOHconstr', options); 
    c_glcin  = x_ott(1);
    c_pyr    = x_ott(2);
    c_ATP    = x_ott(3);
    c_ADP    = c_AXP - c_ATP;
    c_EtOHin = x_ott(4);

    % Computation of the other MeGro outputs 
    g_hxt   = kcat_hxt * c_glcex / ( (c_glcex + KM_hxt) * (1 + c_glcin/KI_glcin) );
    g_gly   = kcat_gly * c_glcin * c_ADP / ( (c_glcin + KM_gly) * (c_ADP + KM_gly_ADP) * (1 + c_pyr/KI_pyr) );
    g_gly2  = kcat_gly2 * c_EtOHin * c_ATP / ( (c_EtOHin + KM_gly2) * (c_ATP + KM_gly2_ATP) * (1 + c_glcin/KI2_glcin) );
    g_rib   = kcat_rib * c_pyr * c_ATP / ( (c_pyr + KM_rib) * (c_ATP + KM_rib_ATP) );
    g_resp  = kcat_resp * c_pyr * c_ADP / ( (c_pyr + KM_resp) * (c_ADP + KM_resp_ADP) );
    g_resp2 = kcat_resp2 * c_EtOHin * c_ADP / ( (c_EtOHin + KM_resp2) * (c_ADP + KM_resp2_ADP) );
    g_ferm  = kcat_ferm * c_pyr / (c_pyr + KM_ferm);   
    g_EtOH  = kcat_EtOH * KM_EtOH * (c_EtOHin - c_EtOHex) / ( (c_EtOHex + KM_EtOH) * (c_EtOHin + KM_EtOH) );

    eta  = g_gly2/g_gly;   
    xi   = g_resp2/g_resp;

    nu_resp  = nu_rib * (1-ferm) * (s_4*s_9 - s_7*(s_8+s_12*eta)) / ( ferm*(1+xi)*s_6*(s_8+s_12*eta) - (1-ferm)*(s_4*(s_10+s_11*xi) - s_5*(s_8+s_12*eta)) );
    nu_ferm  = ( (s_4*(s_10+s_11*xi) - s_5*(s_8+s_12*eta))*nu_resp + (s_4*s_9 - s_7*(s_8+s_12*eta))*nu_rib ) / (s_6*(s_8+s_12*eta));  
    nu_gly   = ( -(s_10+s_11*xi)*nu_resp - s_9*nu_rib ) / (s_8+s_12*eta);
    nu_hxt   = - ((s_2+s_3*eta)/s_1)*nu_gly;
    nu_EtOH  = -(s_13/s_16)*nu_ferm - (s_14*xi/s_16)*nu_resp - (s_15*eta/s_16)*nu_gly;
    nu_resp2 = xi*nu_resp;
    nu_gly2  = eta*nu_gly;

    c_hxt  = nu_hxt/g_hxt;
    c_gly  = nu_gly/g_gly;
    c_rib  = nu_rib/g_rib;
    c_resp = nu_resp/g_resp;
    c_ferm = nu_ferm/g_ferm;

    LambdaMax = nu_rib/(c_hxt + c_gly + c_rib + c_resp + c_ferm)          

    fprintf(fglcex1, '%e\n', c_glcex);
    fprintf(fpercferm1, '%e\n', ferm);
    fprintf(fEtOHex1, '%e\n', c_EtOHex);
    fprintf(flamb1, '%e\n', LambdaMax);
    fprintf(frho1, '%e\n', c_rib/((c_hxt + c_gly + Scaling_rho*c_rib + c_resp + c_ferm)*NaaProt)); %#rib/#aa

   
    % Initialization of the optimization variables for the next step
    c_glcin_0  = x_ott(1);
    c_pyr_0    = x_ott(2);
    c_ATP_0    = x_ott(3);
    c_EtOHin_0 = x_ott(4);
    
end

%% Pure ethanol environment (c_glcex = 0)

% External glucose concentration
c_glcex  = 0.0;

% Data for the external ethanol concentration, transporter investment and fermentative ratio
% WT - CEN.PK
Data_c_EtOHex   = 342.5222;       % 2% ethanol (mM)
Data_F          = 0.0;
Data_gamma_hxt  = 0.01;

% Initializing optimization variables
c_glcin_0    = 1;
c_pyr_0      = 1;
c_ATP_0      = 1e-02;
c_EtOHin_0   = 1;

for i = 1:1:length(Data_F)
    
    % Current fermentative ratio
    ferm     = Data_F(i);
    % Current external glucose concentration
    c_EtOHex  = Data_c_EtOHex(i);
    % Current investment on transporter hxt
    gamma_hxt = Data_gamma_hxt(i); 

    % Optimization problem
    
    x0  = [c_glcin_0 c_pyr_0 c_ATP_0 c_EtOHin_0];
    A   = [];
    b   = [];
    Aeq = [];
    beq = [];
    lb  = [0 0 0 0];      
    ub  = [100 100 1 100];
    
    [x_ott, J_ott, EXITFLAG] = fmincon('MinusLambda_NoGlucose_FixHxt', x0,A,b,Aeq,beq,lb,ub,'EtOHconstr_NoGlucose_FixHxt', options) 
    c_glcin  = x_ott(1);
    c_pyr    = x_ott(2);
    c_ATP    = x_ott(3);
    c_ADP    = c_AXP - c_ATP;
    c_EtOHin = x_ott(4);
    
    % Computation of the other MeGro outputs 
    
    g_hxt   = kcat_hxt * c_glcex / ( (c_glcex + KM_hxt) * (1 + c_glcin/KI_glcin) );
    g_gly   = kcat_gly * c_glcin * c_ADP / ( (c_glcin + KM_gly) * (c_ADP + KM_gly_ADP) * (1 + c_pyr/KI_pyr) );
    g_gly2  = kcat_gly2 * c_EtOHin * c_ATP / ( (c_EtOHin + KM_gly2) * (c_ATP + KM_gly2_ATP) * (1 + c_glcin/KI2_glcin) );
    g_rib   = kcat_rib * c_pyr * c_ATP / ( (c_pyr + KM_rib) * (c_ATP + KM_rib_ATP) );
    g_resp  = kcat_resp * c_pyr * c_ADP / ( (c_pyr + KM_resp) * (c_ADP + KM_resp_ADP) );
    g_resp2 = kcat_resp2 * c_EtOHin * c_ADP / ( (c_EtOHin + KM_resp2) * (c_ADP + KM_resp2_ADP) );
    g_ferm  = kcat_ferm * c_pyr / (c_pyr + KM_ferm);   
    g_EtOH  = kcat_EtOH * KM_EtOH * (c_EtOHin - c_EtOHex) / ( (c_EtOHex + KM_EtOH) * (c_EtOHin + KM_EtOH) );
    
    eta  = g_gly2/g_gly;   
    xi   = g_resp2/g_resp;
    
    nu_resp  = nu_rib * (1-ferm) * (s_4*s_9 - s_7*(s_8+s_12*eta)) / ( ferm*(1+xi)*s_6*(s_8+s_12*eta) - (1-ferm)*(s_4*(s_10+s_11*xi) - s_5*(s_8+s_12*eta)) );
    nu_ferm  = ( (s_4*(s_10+s_11*xi) - s_5*(s_8+s_12*eta))*nu_resp + (s_4*s_9 - s_7*(s_8+s_12*eta))*nu_rib ) / (s_6*(s_8+s_12*eta));  
    nu_gly   = ( -(s_10+s_11*xi)*nu_resp - s_9*nu_rib ) / (s_8+s_12*eta);
    nu_hxt   = - ((s_2+s_3*eta)/s_1)*nu_gly;
    nu_EtOH  = -(s_13/s_16)*nu_ferm - (s_14*xi/s_16)*nu_resp - (s_15*eta/s_16)*nu_gly;
    nu_resp2 = xi*nu_resp;
    nu_gly2  = eta*nu_gly;
    
    c_gly  = nu_gly/g_gly;
    c_rib  = nu_rib/g_rib;
    c_resp = nu_resp/g_resp;
    c_ferm = nu_ferm/g_ferm;
    
    c_hxt   = (gamma_hxt/(1-gamma_hxt))*(c_gly + c_rib*NprotRib + c_resp + c_ferm);
    
    LambdaMax = nu_rib/(c_hxt + c_gly + c_rib + c_resp + c_ferm)          
    
    fprintf(fglcex2, '%e\n', c_glcex);
    fprintf(fpercferm2, '%e\n', ferm);
    fprintf(fEtOHex2, '%e\n', c_EtOHex);
    fprintf(flamb2, '%e\n', LambdaMax);
    fprintf(frho2, '%e\n', c_rib/((c_hxt + c_gly + Scaling_rho*c_rib + c_resp + c_ferm)*NaaProt)); %#rib/#aa 
    
    fprintf(fgammahxt2,'%e\n', c_hxt/(c_hxt + c_gly + NprotRib*c_rib + c_resp + c_ferm));
    
    % Initialization of the optimization variables for the next step
    c_glcin_0  = x_ott(1);
    c_pyr_0    = x_ott(2);
    c_ATP_0    = x_ott(3);
    c_EtOHin_0 = x_ott(4);
    
end

%% Closing files

fclose(flamb1);
fclose(frho1);
fclose(fglcex1);
fclose(fpercferm1);
fclose(fEtOHex1);

fclose(flamb2);
fclose(frho2);
fclose(fglcex2);
fclose(fpercferm2);
fclose(fEtOHex2);

fclose(fgammahxt2);

%% Evaluation of Grocy Parameters

GrocyParEval