function dx = GCMfun(t,x)

    global K1 D1 rho K2 D2 Kon Koff Kcn Knc teta H h;
    global TG1 k;
        
    P           = x(1);
    R           = x(2);
    Cln3        = x(3);
    Far1        = x(4);
    Cln3Far1    = x(5);

    Cln3_tot    = teta*P;
    Cln3_cyt    = Cln3_tot - (Cln3 + Cln3Far1);
    V           = h*P/H;

    if (k == 0)

        k2 = K2(1);
        d2 = D2(1);

    else

       if (t <= TG1)

            k2 = K2(k+1);
            d2 = D2(k+1);
       else

            k2 = K2(1);
            d2 = D2(1);

       end
    end

    dP          = k2*R - P/d2;
    dR          = K1*max(rho*P - R,0) - R/D1;
    dCln3       = -Kon*Cln3*Far1/V + Koff*Cln3Far1 + Kcn*Cln3_cyt - Knc*Cln3;
    dFar1       = -Kon*Cln3*Far1/V + Koff*Cln3Far1 - eta_f(Cln3, Cln3Far1)*Far1;
    dCln3Far1   = Kon*Cln3*Far1/V - Koff*Cln3Far1;

    dx          = [dP; dR; dCln3; dFar1; dCln3Far1];
    
end

