clear all;
close all;
clc;


%Parameter definition

global K1 D1 rho K2 D2 Kon Koff Kcn Knc eta nF teta H h; 
global Tsizer T1 W0 W1 T1min T2 TB;
global Psizer;
global Ps;
global TG1 k;
global Far1reset;
global Kcnreset;

Ps=zeros(8,1);

%%

%Parameter setting: low glucose (0.05%)
K1       = 1;
D1       = 4000;

Kon      = 1.6284*10^(-15);           %L^-1*m^-1
Koff     = 25;                      %min^-1

Kcn      = 1.5;                     %min^-1
Knc      = 0.6;                     %min^-1
Kcnreset = 5E-4;                     %min^-1

eta      = 1;                       %min^-1
nF       = 10;                      %-

teta     = 3.02*10^(-8);            %molec/aa
H        = 7.09*10^(23);            %aa/L
h        = 0.07;                    %-

T1min    = 1;                       %min
T2       = 10;                      %min

rho_l        = 1.881E-5;

P0_l         = 1.1566E10;               %aa      
R0_l         = P0_l*rho_l;              %num rib
Far10_l      = 170;                     %num molecules
Cln30_l      = 1;                       %num molecules
Cln3Far10_l  = 2;                       %num molecules
Far1reset_l  = 170;                     %num molecules

K2d_l         = 318;
D2d_l         = 3000;
K2p_l         = [290; 155; 65; 50; 43; 37; 37];
D2p_l         = [1500; 1500; 1500; 1500; 1500; 1500; 1500];

W0_l         = 1496.2;                  %min
W1_l         = 62.1184;                 %min
TB_l         = 90;                      %min

%%

%Daughter - Low Glucose (0.05%)
%Sizer

k           = 0;
ti          = 0;                       %min
tf          = 30;                      %min
TG1         = tf;                      %min

rho         = rho_l;
K2          = [K2d_l; K2p_l];
D2          = [D2d_l; D2p_l];

TB          = TB_l;                     %min
W0          = W0_l;                     %min
W1          = W1_l;                     %min

P0          = P0_l;
R0          = R0_l;
Cln30       = Cln30_l;
Far10       = Far10_l;
Cln3Far10   = Cln3Far10_l;
Far1reset   = Far1reset_l;

[t, x]=ode45(@GCMfun, [ti tf], [P0, R0, Cln30, Far10, Cln3Far10]);

P           = x(:,1);
Cln3        = x(:,3);
Cln3Far1    = x(:,5);

%Computation of Psizer and Tsizer!

Nsize=size(t);
N=Nsize(1,1);

ichange=0;
isizer=0;

%Searching for the time instant such that Cln3>=Cln3Far1 (Cln3(0)<Far1(0))

for i=1:1:N
    if (Cln3(i)>=Cln3Far1(i))      
        isizer=i;
        break;
    end
end



%We verified the condition Cln3>=Cln3Far1 from now on  

for i=isizer:1:N   

    if (Cln3(i)<=Cln3Far1(i))     %If it is isizer=0 such a condition will break an error message!
        ichange=i;
        break;
    end

end

if ichange > 0
    
    for i=ichange:1:N

        if (Cln3(i)>=Cln3Far1(i))      
            isizer=i;
            break;
        end

    end
 
end

Tsizer = t(isizer);
Psizer = P(isizer);

T1 = max(T1min, W0 - W1*log(Psizer));
TG1 = Tsizer + T1 + T2;

%G1 phase + TB-G1*

ti          = 0;                                %min
tf          = TG1 + 0.8*TB;                      %min

[t1, x1]=ode45(@GCMfun, [ti tf], [P0, R0, Cln30, Far10, Cln3Far10]);

%G1* phase

ti          = t1(end);                       %min
tf          = TG1 + TB;                      %min

[t2, x2]=ode45(@GCMfun_reset, [ti tf], [x1(end,1), x1(end,2), x1(end,3)/2, Far1reset, x1(end,5)/2]);

t           = [t1(1:end-1); t2];
P           = [x1(1:end-1,1);x2(:,1)];
R           = [x1(1:end-1,2);x2(:,2)];
Cln3        = [x1(1:end-1,3);x2(:,3)];
Far1        = [x1(1:end-1,4);x2(:,4)];
Cln3Far1    = [x1(1:end-1,5);x2(:,5)];

Cln3_tot    = teta*P;
Cln3_cyt    = Cln3_tot - [x1(1:end-1,3) + x1(1:end-1,5); 2*(x2(:,3) + x2(:,5))];

%Computation of Ps for daughter cells
Nsize=size(t);
N=Nsize(1,1);

for i=1:1:N-1
   if (t(i) <= TG1) && (t(i+1) > TG1) 
       Ps(1) = P(i) + (P(i+1) - P(i))*(TG1 - t(i))/(t(i+1) - t(i));
   end
end

%figure 1
figure1 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes1 = axes('Parent',figure1, 'YTick', [1 2 3 4 5 6 7], 'YScale','log','FontSize',34);
box(axes1,'on');
grid(axes1,'off');
hold(axes1,'all');

semilogy(t, P/1e10, 'Parent',axes1, 'LineStyle','-', 'Color', 'black', 'linewidth', 3), hold on;
semilogy(t, R/1e5, 'Parent',axes1, 'LineStyle','-', 'Color', 'r', 'linewidth', 3);
g=legend(axes1, 'P', 'R');
set(g,'FontSize', 34,'FontWeight','bold', 'Location', 'SouthEast'); 
xlabel('Parent',axes1,'time - (min)', 'FontSize',34,'Interpreter','Tex');
ylabel('Parent',axes1, ['Protein content - (#aa*10^{10})',sprintf('\n'),'Number of ribosomes*10^{5}'],...
    'FontSize',34,'Interpreter','Tex');
title('glucose 0.05%');

saveas(figure1,'P&R_l.png')
saveas(figure1,'P&R_l.fig')

%figure 2
figure2 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes2 = axes('Parent',figure2,'FontSize',34);
box(axes2,'on');
grid(axes2,'off');
hold(axes2,'all');

plot(t, Far1, 'Parent',axes2, 'LineStyle','-', 'Color', 'g', 'linewidth', 3), hold on;
plot(t, Cln3_cyt, 'Parent',axes2, 'LineStyle','-', 'Color', 'b', 'linewidth', 3);
plot(t, Cln3, 'Parent',axes2, 'LineStyle','-', 'Color', 'r', 'linewidth', 3);
plot(t, Cln3Far1, 'Parent',axes2, 'LineStyle','-', 'Color', 'k', 'linewidth', 3);
plot(t, Cln3_tot, 'Parent',axes2, 'LineStyle','-', 'Color', 'm', 'linewidth', 3);
plot(Tsizer, 0, 'Parent',axes2, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);
plot(Tsizer+T1, 0, 'Parent',axes2, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);
plot(Tsizer+T1+T2, 0, 'Parent',axes2, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);
plot(Tsizer+T1+T2+0.8*TB, 0, 'Parent',axes2, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);
plot(Tsizer+T1+T2+TB, 0, 'Parent',axes2, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);

g=legend(axes2, 'Far1', 'Cln3_{cyt}', 'Cln3_{nuc}', 'Cln3Far1', 'Cln3_{tot}');
set(g,'FontSize', 34,'FontWeight','bold', 'Location', 'SouthEast'); 
xlabel('Parent',axes2,'time - (min)', 'FontSize',34,'Interpreter','Tex');
ylabel('Parent',axes2,'Number of molecules', 'FontSize',34,'Interpreter','Tex');
title('glucose 0.05%');

saveas(figure2,'Players_l.png')
saveas(figure2,'Players_l.fig')



%Parent k=1,...,7 - Low Glucose (0.05%)
%Sizer

%figure 3
figure3 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes3 = axes('Parent',figure3, 'YTick', [1 2 3 4 5 6 7],'YScale','log','FontSize',34);
box(axes3,'on');
grid(axes3,'off');
hold(axes3,'all');

for k=1:1:7
    
    ti          = 0;                       %min
    tf          = 10;                      %min
    TG1         = tf;                      %min

    rho         = rho_l;
    K2          = [K2d_l; K2p_l];
    D2          = [D2d_l; D2p_l];

    TB          = TB_l;                     %min
    W0          = W0_l;                     %min
    W1          = W1_l;                     %min

    P0          = Ps(k);
    R0          = rho_l*Ps(k);    
    Cln30       = Cln30_l;
    Far10       = Far10_l;
    Cln3Far10   = Cln3Far10_l;
    Far1reset   = Far1reset_l;

    [t, x]=ode45(@GCMfun, [ti tf], [P0, R0, Cln30, Far10, Cln3Far10]);

    P           = x(:,1);
    Cln3        = x(:,3);
    Cln3Far1    = x(:,5);

    %Computation of Psizer and Tsizer!

    Nsize=size(t);
    N=Nsize(1,1);

    ichange=0;
    isizer=0;

    %Searching for the time instant such that Cln3>=Cln3Far1 (Cln3(0)<Far1(0))

    for i=1:1:N

        if (Cln3(i)>=Cln3Far1(i))      
            isizer=i;
            break;
        end
    end

    %We verified the condition Cln3>=Cln3Far1 from now on  

    for i=isizer:1:N

        if (Cln3(i)<=Cln3Far1(i))     %If it is isizer=0 such a condition will break an error message!
            ichange=i;
            break;
        end

    end

    if ichange > 0

        for i=ichange:1:N

            if (Cln3(i)>=Cln3Far1(i))     
                isizer=i;
                break;
            end

        end

    end

    Tsizer = t(isizer);
    Psizer = P(isizer);

    T1 = max(T1min, W0 - W1*log(Psizer));
    TG1 = Tsizer + T1 + T2;

    %G1 phase + TB-G1*

    ti          = 0;                                %min
    tf          = TG1 + 0.8*TB;                      %min

    [t1, x1]=ode45(@GCMfun, [ti tf], [P0, R0, Cln30, Far10, Cln3Far10]);

    %G1* phase

    ti          = t1(end);                       %min
    tf          = TG1 + TB;                      %min

    [t2, x2]=ode45(@GCMfun_reset, [ti tf], [x1(end,1), x1(end,2), x1(end,3)/2, Far1reset, x1(end,5)/2]);

    t           = [t1(1:end-1); t2];
    P           = [x1(1:end-1,1);x2(:,1)];
    %R           = [x1(1:end-1,2);x2(:,2)];
    %Cln3        = [x1(1:end-1,3);x2(:,3)];
    %Far1        = [x1(1:end-1,4);x2(:,4)];
    %Cln3Far1    = [x1(1:end-1,5);x2(:,5)];

    %Cln3_tot    = teta*P;
    %Cln3_cyt    = Cln3_tot - [x1(1:end-1,3) + x1(1:end-1,5); 2*(x2(:,3) + x2(:,5))];

    %Computation of Ps for parent cells
    Nsize=size(t);
    N=Nsize(1,1);

    for i=1:1:N-1
       if (t(i) <= TG1) && (t(i+1) > TG1) 
           Ps(k+1) = P(i) + (P(i+1) - P(i))*(TG1 - t(i))/(t(i+1) - t(i));
       end
    end
    
    semilogy(t, P/1e10, 'Parent',axes3, 'LineStyle','-', 'linewidth', 3), hold on;
   
end

g=legend(axes3, 'Parent P1', 'Parent P2', 'Parent P3', 'Parent P4', 'Parent P5', 'Parent P6', 'Parent P7');
set(g,'FontSize', 34,'FontWeight','bold', 'Location', 'SouthEast'); 
xlabel('Parent',axes3, 'time - (min)', 'FontSize',34,'Interpreter','Tex');
ylabel('Parent',axes3, 'Protein content - (#aa*10^{10})', 'FontSize',34,'Interpreter','Tex');
title('glucose 0.05%');

saveas(figure3,'P_parent_l.png')
saveas(figure3,'P_parent_l.fig')

%figure 4
figure4 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes4 = axes('Parent',figure4,'FontSize',34);
box(axes4,'on');
grid(axes4,'off');
hold(axes4,'all');

plot([0;1;2;3;4;5;6;7], Ps, 'Parent',axes4, 'Marker','o', 'MarkerEdgeColor','b','MarkerFaceColor','b', 'markersize', 20, ...
    'LineStyle','-', 'Color', 'b', 'linewidth', 3), hold on;

%g=legend(axes4, 'D', 'P_{1}', 'P_{2}', 'P_{3}', 'P_{4}', 'P_{5}', 'P_{6}', 'P_{7}');
%set(g,'FontSize', 24,'FontWeight','bold', 'Location', 'SouthEast'); 
xlabel('Parent',axes4,'Number of bud scars', 'FontSize',34,'Interpreter','Tex');
ylabel('Parent',axes4,'P_{s}', 'FontSize',34,'Interpreter','Tex');
title('glucose 0.05%');

saveas(figure4,'Ps_l.png')
saveas(figure4,'Ps_l.fig')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
%Parameter setting: high glucose (2%)

K1       = 1;
D1       = 4000;

Kon      = 1.6284*10^(-15);           %L^-1*m^-1
Koff     = 25;                      %min^-1

Kcn      = 1.5;                     %min^-1
Knc      = 0.6;                     %min^-1
Kcnreset = 5E-4;                     %min^-1

eta      = 1;                       %min^-1
nF       = 10;                      %-

teta     = 3.02*10^(-8);            %molec/aa
H        = 7.09*10^(23);            %aa/L
h        = 0.07;                    %-

T1min    = 1;                       %min
T2       = 10;                      %min

rho_h        = 2.018E-5;

P0_h         = 2.7554E10;               %aa      
R0_h         = P0_h*rho_h;                   %num rib
Far10_h      = 240;                     %num molecules
Cln30_h      = 1;                       %num molecules
Cln3Far10_h  = 2;                       %num molecules
Far1reset_h  = 240;

K2d_h         = 380;
D2d_h         = 3000;
K2p_h         = [342; 178; 69; 51; 42; 35; 35];
D2p_h         = [1500; 1500; 1500; 1500; 1500; 1500; 1500];

W0_h         = 1503.0;                  %min
W1_h         = 62.10;                   %min
TB_h         = 85;                      %min

%%

%Daughter - High Glucose (2%)
%Sizer!

k           = 0;
ti          = 0;                       %min
tf          = 10;                      %min
TG1         = tf;                      %min

rho         = rho_h;
K2          = [K2d_h; K2p_h];
D2          = [D2d_h; D2p_h];

TB          = TB_h;                     %min
W0          = W0_h;                     %min
W1          = W1_h;                     %min

P0          = P0_h;
R0          = R0_h;
Cln30       = Cln30_h;
Far10       = Far10_h;
Cln3Far10   = Cln3Far10_h;
Far1reset   = Far1reset_h;

[t, x]=ode45(@GCMfun, [ti tf], [P0, R0, Cln30, Far10, Cln3Far10]);

P           = x(:,1);
Cln3        = x(:,3);
Cln3Far1    = x(:,5);

%Computation of Psizer and Tsizer!

Nsize=size(t);
N=Nsize(1,1);

ichange=0;
isizer=0;

%Searching for the time instant such that Cln3>=Cln3Far1 (Cln3(0)<Far1(0))

for i=1:1:N

    if (Cln3(i)>=Cln3Far1(i))      
        isizer=i;
        break;
    end
end

%We verified the condition Cln3>=Cln3Far1 from now on  

for i=isizer:1:N

    if (Cln3(i)<=Cln3Far1(i))     %If it is isizer=0 such a condition will break an error message!
        ichange=i;
        break;
    end

end

if ichange > 0
    
    for i=ichange:1:N

        if (Cln3(i)>=Cln3Far1(i))     
            isizer=i;
            break;
        end

    end
 
end

Tsizer = t(isizer);
Psizer = P(isizer);

T1 = max(T1min, W0 - W1*log(Psizer));
TG1 = Tsizer + T1 + T2;

%G1 phase + TB-G1* pahse

ti          = 0;                                %min
tf          = TG1 + 0.8*TB;                      %min

[t1, x1]=ode45(@GCMfun, [ti tf], [P0, R0, Cln30, Far10, Cln3Far10]);

%G1* phase

ti          = t1(end);                       %min
tf          = TG1 + TB;                      %min

[t2, x2]=ode45(@GCMfun_reset, [ti tf], [x1(end,1), x1(end,2), x1(end,3)/2, Far1reset, x1(end,5)/2]);

t           = [t1(1:end-1); t2];
P           = [x1(1:end-1,1);x2(:,1)];
R           = [x1(1:end-1,2);x2(:,2)];
Cln3        = [x1(1:end-1,3);x2(:,3)];
Far1        = [x1(1:end-1,4);x2(:,4)];
Cln3Far1    = [x1(1:end-1,5);x2(:,5)];

Cln3_tot    = teta*P;
Cln3_cyt    = Cln3_tot - [x1(1:end-1,3) + x1(1:end-1,5); 2*(x2(:,3) + x2(:,5))];

%Computation of Ps for daughter cells
Nsize=size(t);
N=Nsize(1,1);

for i=1:1:N-1
   if (t(i) <= TG1) && (t(i+1) > TG1) 
       Ps(1) = P(i) + (P(i+1) - P(i))*(TG1 - t(i))/(t(i+1) - t(i));
   end
end

%figure 5
figure5 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes5 = axes('Parent',figure5, 'YTick', [1 2 3 4 5 10 20], 'YScale','log','FontSize',34);
box(axes5,'on');
grid(axes5,'off');
hold(axes5,'all');

semilogy(t, P/1e10, 'Parent',axes5, 'LineStyle','-', 'Color', 'black', 'linewidth', 3), hold on;
semilogy(t, R/1e5, 'Parent',axes5, 'LineStyle','-', 'Color', 'r', 'linewidth', 3);
g=legend(axes5, 'P', 'R');
set(g,'FontSize', 34,'FontWeight','bold', 'Location', 'SouthEast'); 
xlabel('Parent',axes5,'time - (min)', 'FontSize',34,'Interpreter','Tex');
ylabel('Parent',axes5, ['Protein content - (#aa*10^{10})',sprintf('\n'),'Number of ribosomes*10^{5}'],...
    'FontSize',34,'Interpreter','Tex');
title('glucose 2%');

saveas(figure5,'P&R_h.png')
saveas(figure5,'P&R_h.fig')

%figure 6
figure6 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes6 = axes('Parent',figure6,'FontSize',34);
box(axes6,'on');
grid(axes6,'off');
hold(axes6,'all');

plot(t, Far1, 'Parent',axes6, 'LineStyle','-', 'Color', 'g', 'linewidth', 3), hold on;
plot(t, Cln3_cyt, 'Parent',axes6, 'LineStyle','-', 'Color', 'b', 'linewidth', 3);
plot(t, Cln3, 'Parent',axes6, 'LineStyle','-', 'Color', 'r', 'linewidth', 3);
plot(t, Cln3Far1, 'Parent',axes6, 'LineStyle','-', 'Color', 'k', 'linewidth', 3);
plot(t, Cln3_tot, 'Parent',axes6, 'LineStyle','-', 'Color', 'm', 'linewidth', 3);
plot(Tsizer, 0, 'Parent',axes6, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);
plot(Tsizer+T1, 0, 'Parent',axes6, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);
plot(Tsizer+T1+T2, 0, 'Parent',axes6, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);
plot(Tsizer+T1+T2+0.8*TB, 0, 'Parent',axes6, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);
plot(Tsizer+T1+T2+TB, 0, 'Parent',axes6, 'Marker','+', 'LineStyle','none', 'MarkerEdgeColor','k','MarkerFaceColor','k', 'markersize', 20);

g=legend(axes6, 'Far1', 'Cln3_{cyt}', 'Cln3_{nuc}', 'Cln3Far1', 'Cln3_{tot}');
set(g,'FontSize', 34,'FontWeight','bold', 'Location', 'SouthEast'); 
xlabel('Parent',axes6,'time - (min)', 'FontSize',34,'Interpreter','Tex');
ylabel('Parent',axes6,'Number of molecules', 'FontSize',34,'Interpreter','Tex');
title('glucose 2%');

saveas(figure6,'Players_h.png')
saveas(figure6,'Players_h.fig')

%Parent k=1,...,7 - High Glucose (2%)
%Sizer!

%figure 7
figure7 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes7 = axes('Parent',figure7, 'YTick', [1 2 3 4 5 6 7],'YScale','log','FontSize',34);
box(axes7,'on');
grid(axes7,'off');
hold(axes7,'all');

for k=1:1:7
    
    ti          = 0;                       %min
    tf          = 10;                      %min
    TG1         = tf;                      %min

    rho         = rho_h;
    K2          = [K2d_h; K2p_h];
    D2          = [D2d_h; D2p_h];

    TB          = TB_h;                     %min
    W0          = W0_h;                     %min
    W1          = W1_h;                     %min

    P0          = Ps(k);
    R0          = rho_h*Ps(k);    
    Cln30       = Cln30_h;
    Far10       = Far10_h;
    Cln3Far10   = Cln3Far10_h;
    Far1reset   = Far1reset_h;
    
    [t, x]=ode45(@GCMfun, [ti tf], [P0, R0, Cln30, Far10, Cln3Far10]);

    P           = x(:,1);
    Cln3        = x(:,3);
    Cln3Far1    = x(:,5);

    %Computation of Tsizer and Psizer

    Nsize=size(t);
    N=Nsize(1,1);

    ichange=0;
    isizer=0;

    %Searching for the time instant such that Cln3>=Cln3Far1 (Cln3(0)<Far1(0))

    for i=1:1:N

        if (Cln3(i)>=Cln3Far1(i))      
            isizer=i;
            break;
        end
    end

   %We verified the condition Cln3>=Cln3Far1 from now on  

    for i=isizer:1:N

        if (Cln3(i)<=Cln3Far1(i))     %If it is isizer=0 such a condition will break an error message!
            ichange=i;
            break;
        end

    end

 
    if ichange > 0

        for i=ichange:1:N

            if (Cln3(i)>=Cln3Far1(i))     
                isizer=i;
                break;
            end

        end

    end

    Tsizer = t(isizer);
    Psizer = P(isizer);

    T1 = max(T1min, W0 - W1*log(Psizer));
    TG1 = Tsizer + T1 + T2;

    %G1 phase + TB-G1* phase
    
    ti          = 0;                                %min
    tf          = TG1 + 0.8*TB;                      %min

    [t1, x1]=ode45(@GCMfun, [ti tf], [P0, R0, Cln30, Far10, Cln3Far10]);

    %G1* phase

    ti          = t1(end);                       %min
    tf          = TG1 + TB;                      %min

    [t2, x2]=ode45(@GCMfun_reset, [ti tf], [x1(end,1), x1(end,2), x1(end,3)/2, Far1reset, x1(end,5)/2]);

    t           = [t1(1:end-1); t2];
    P           = [x1(1:end-1,1);x2(:,1)];
    %R           = [x1(1:end-1,2);x2(:,2)];
    %Cln3        = [x1(1:end-1,3);x2(:,3)];
    %Far1        = [x1(1:end-1,4);x2(:,4)];
    %Cln3Far1    = [x1(1:end-1,5);x2(:,5)];

    %Cln3_tot    = teta*P;
    %Cln3_cyt    = Cln3_tot - [x1(1:end-1,3) + x1(1:end-1,5); 2*(x2(:,3) + x2(:,5))];

    %Calcolo della Ps della parent
    Nsize=size(t);
    N=Nsize(1,1);

    for i=1:1:N-1
       if (t(i) <= TG1) && (t(i+1) > TG1) 
           Ps(k+1) = P(i) + (P(i+1) - P(i))*(TG1 - t(i))/(t(i+1) - t(i));
       end
    end
    
    semilogy(t, P/1e10, 'Parent',axes7, 'LineStyle','-', 'linewidth', 3), hold on;
   
end

g=legend(axes7, 'Parent P1', 'Parent P2', 'Parent P3', 'Parent P4', 'Parent P5', 'Parent P6', 'Parent P7');
set(g,'FontSize', 34,'FontWeight','bold', 'Location', 'SouthEast'); 
xlabel('Parent',axes7, 'time - (min)', 'FontSize',34,'Interpreter','Tex');
ylabel('Parent',axes7, 'Protein content - (#aa*10^{10})', 'FontSize',34,'Interpreter','Tex');
title('glucose 2%');

saveas(figure7,'P_parent_h.png')
saveas(figure7,'P_parent_h.fig')

%figure 8
figure8 = figure('PaperSize',[20.98 29.68]);

% Create axes
axes8 = axes('Parent',figure8,'FontSize',34);
box(axes8,'on');
grid(axes8,'off');
hold(axes8,'all');

plot([0;1;2;3;4;5;6;7], Ps, 'Parent',axes8, 'Marker','o', 'MarkerEdgeColor','b','MarkerFaceColor','b', 'markersize', 20, ...
    'LineStyle','-', 'Color', 'b', 'linewidth', 3), hold on;

%g=legend(axes8, 'D', 'P_{1}', 'P_{2}', 'P_{3}', 'P_{4}', 'P_{5}', 'P_{6}', 'P_{7}');
%set(g,'FontSize', 24,'FontWeight','bold', 'Location', 'SouthEast'); 
xlabel('Parent',axes8,'Number of bud scars', 'FontSize',34,'Interpreter','Tex');
ylabel('Parent',axes8,'P_{s}', 'FontSize',34,'Interpreter','Tex');
title('glucose 2%');

saveas(figure8,'Ps_h.png')
saveas(figure8,'Ps_h.fig')
