function f = eta_f(y, z)

    global eta nF;
    
    if (z~=0)
        
        f = eta*(y/z)^nF/((y/z)^nF + 1);
        
    else
        
        f = eta*y^nF/(y^nF + z^nF);

    end
    
end

